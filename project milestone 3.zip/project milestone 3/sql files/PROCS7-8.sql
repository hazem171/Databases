﻿CREATE PROC addDelivery 
@delivery_type varchar(20),
@time_duration int,
@fees decimal(5,3),
@admin_username varchar(20)
AS
INSERT INTO Delivery
VALUES(@time_duration,@delivery_type,@fees,@admin_username)


GO
CREATE PROC assignOrdertoDelivery 
@delivery_username varchar(20),
@order_no int,
@admin_username varchar(20)
AS
INSERT INTO Admin_Delivery_Order
VALUES(@delivery_username, @order_no,@admin_username, NULL)

GO
CREATE PROC createTodaysDeal 
@deal_amount int,
@admin_username varchar(20),
@expiry_date datetime
AS
INSERT INTO Todays_Deals
VALUES(@deal_amount,@expiry_date,@admin_username)

GO
CREATE PROC checkTodaysDealOnProduct
@serial_no INT,
@activeDeal BIT OUTPUT
AS
DECLARE @final DECIMAL(10,2)
DECLARE @price DECIMAL(10,2)
SELECT @final=final_price, @price= price
FROM Product
WHERE serial_no = @serial_no
IF(@final=@price)
BEGIN
SET @activeDeal='0';
END
ELSE
BEGIN
SET @activeDeal='1';
END

GO
CREATE PROC addTodaysDealOnProduct
@deal_id int,
@serial_no int
AS
DECLARE @amount DECIMAL(10,2)
SELECT @amount = deal_amount
FROM Todays_Deals
WHERE deal_id = @deal_id
UPDATE Product
SET final_price = price-((@amount/100)*price)
WHERE serial_no=@serial_no
INSERT INTO Todays_Deals_Product
VALUES(@deal_id,@serial_no)

GO
CREATE PROC removeExpiredDeal
@deal_id INT
AS
DELETE FROM Todays_Deals
WHERE expiry_date < CURRENT_TIMESTAMP AND deal_id = @deal_id

GO
CREATE PROC createGiftCard
@code varchar(10),
@expiry_date datetime,
@amount int,
@admin_username varchar(20)
AS
INSERT INTO Giftcard
VALUES(@code,@expiry_date,@amount,@admin_username)

GO
CREATE PROC removeExpiredGiftCard
@code VARCHAR(20)
AS
DECLARE @GIFTP INT
SELECT @GIFTP=amount FROM Giftcard WHERE @code=code
IF((SELECT [expiry_date] FROM Giftcard WHERE @code=code)<CURRENT_TIMESTAMP)
BEGIN
UPDATE Customer 
SET points =points-@GIFTP
FROM Customer C INNER JOIN Admin_Customer_Giftcard A ON A.customer_name=C.username
WHERE @code=A.code
DELETE FROM Giftcard
WHERE @code = code
DELETE FROM Admin_Customer_Giftcard
WHERE @code=code
UPDATE Customer
SET points = 0
WHERE points < 0
END
GO
CREATE PROC checkGiftCardOnCustomer
@code VARCHAR(10),
@activeGiftCard BIT OUTPUT
AS
IF((SELECT [expiry_date] FROM Giftcard WHERE @code=code)<CURRENT_TIMESTAMP OR @code NOT IN (SELECT code FROM Giftcard) )
SET @activeGiftCard = '0'
ELSE
SET @activeGiftCard = '1'

GO
CREATE PROC giveGiftCardtoCustomer
@code varchar(10),
@customer_name varchar(20),
@admin_username varchar(20)
AS
DECLARE @amount INT,@points INT
SELECT @amount = amount
FROM Giftcard
WHERE code=@code
SELECT @points = amount FROM Giftcard WHERE @code=code
INSERT INTO Admin_Customer_Giftcard VALUES(@code,@customer_name,@admin_username,@points)
UPDATE Customer
SET points = points + @amount
WHERE username = @customer_name


GO
CREATE PROC acceptAdminInvitation
@delivery_username varchar(20)
AS
UPDATE Delivery_Person
SET is_activated = '1'
WHERE @delivery_username=username

GO
CREATE PROC deliveryPersonUpdateInfo
@username varchar(20),
@first_name varchar(20),
@last_name varchar(20),
@password varchar(20),
@email varchar(50)
AS
UPDATE Users
SET first_name=@first_name,last_name=@last_name,[password]=@password,email=@email
WHERE username = @username

GO
CREATE PROC viewmyorders
@deliveryperson varchar(20)
AS
SELECT *
FROM Orders O INNER JOIN Admin_Delivery_Order A ON O.order_no = A.order_no
WHERE @deliveryperson=A.delivery_username

GO
CREATE PROC specifyDeliveryWindow
@delivery_username varchar(20),
@order_no int,
@delivery_window varchar(50)
AS
UPDATE Admin_Delivery_Order
SET delivery_window = @delivery_window
WHERE @delivery_username = delivery_username AND order_no=@order_no

GO
CREATE PROC updateOrderStatusOutforDelivery
@order_no INT
AS
UPDATE Orders
SET order_status = 'Out for delivery'
WHERE order_no = @order_no

GO
CREATE PROC updateOrderStatusDelivered
@order_no INT
AS
UPDATE Orders
SET order_status = 'Delivered'
WHERE order_no = @order_no
