﻿
CREATE TABLE Users(
username VARCHAR(20),
[password] VARCHAR(20), 
first_name VARCHAR(20), 
last_name VARCHAR(20), 
email VARCHAR(50)
PRIMARY KEY(username))

--Users mobile numbers
CREATE TABLE User_mobile_numbers(
mobile_number varchar(20),
username varchar(20),
PRIMARY KEY(username,mobile_number),
FOREIGN KEY(username) REFERENCES Users ON DELETE CASCADE ON UPDATE CASCADE  
);
--Users addresses
CREATE TABLE User_Addresses(
address varchar(100),
username varchar(20),
PRIMARY KEY(address,username),
FOREIGN KEY(username) REFERENCES Users ON DELETE CASCADE ON UPDATE CASCADE
);
--Customer
CREATE TABLE Customer(
username varchar(20),
points INT,--change points later
PRIMARY KEY(username),
FOREIGN KEY(username) REFERENCES Users ON DELETE CASCADE ON UPDATE CASCADE
);
--Admins
CREATE TABLE Admins(
username varchar(20),
PRIMARY KEY(username),
FOREIGN KEY(username) REFERENCES Users ON DELETE CASCADE ON UPDATE CASCADE
);
--Vendor
CREATE TABLE Vendor(
username varchar(20),
activated bit,--check
company_name varchar(20),
bank_acc_no varchar(20),
admin_username varchar(20),
PRIMARY KEY(username),
FOREIGN KEY(username) REFERENCES Users ON DELETE CASCADE ON UPDATE CASCADE,
FOREIGN KEY(admin_username) REFERENCES Admins ON DELETE NO ACTION ON UPDATE NO ACTION--check the cascade part
);
--Delivery_Person
CREATE TABLE Delivery_Person(
username varchar(20),
is_activated bit,--check 
PRIMARY KEY(username),
FOREIGN KEY(username) REFERENCES Users ON DELETE CASCADE ON UPDATE CASCADE
);
--Credit_Card
CREATE TABLE Credit_Card(
number varchar(20),--check time
[expiry_date] date,
cvv_code varchar(4),--check later
PRIMARY KEY(number)
);
--Delivery
CREATE TABLE Delivery(
id INT IDENTITY ,--check
time_duration INT,
[type] VARCHAR(20),
fees decimal(5,3),
username varchar(20),
PRIMARY KEY(id),
FOREIGN KEY(username) REFERENCES Admins ON DELETE set null ON UPDATE CASCADE--check
);

--giFTCARD
CREATE TABLE Giftcard( 
code varchar(10),
[expiry_date] datetime,
amount int,
username varchar(20),
PRIMARY KEY(code),
FOREIGN KEY (username) REFERENCES Admins ON DELETE set null ON UPDATE CASCADE
);

--Orders
CREATE TABLE Orders(
order_no INT IDENTITY ,
order_date datetime,
total_amount INT,
cash_amount decimal(10,2),
credit_amount decimal(10,2),
payment_type varchar(20),
order_status varchar(20),
remaining_days INT,
time_limit varchar(20),
Gift_Card_code_used  varchar(10) ,--check when uou create giftcard
customer_name varchar(20),
delivery_id INT,
creditCard_number varchar(20),
PRIMARY KEY(order_no),
FOREIGN KEY(Gift_Card_code_used) REFERENCES GiftCard ON DELETE set null ON UPDATE CASCADE,
FOREIGN KEY(creditCard_number) REFERENCES Credit_Card ON DELETE set null ON UPDATE CASCADE,
FOREIGN KEY(delivery_id) REFERENCES Delivery ON DELETE NO ACTION ON UPDATE NO ACTION,--check
FOREIGN KEY(customer_name) REFERENCES Customer ON DELETE NO ACTION ON UPDATE NO ACTION
);
--Product
CREATE TABLE Product(
serial_no int IDENTITY,
product_name varchar(20),
category varchar(20),
product_description text,
price DECIMAL(10,2),
final_price decimal(10,2),
color varchar(20),
available BIT,
rate INT,
vendor_username varchar(20),
customer_username varchar(20),
customer_order_id INT,
PRIMARY KEY (serial_no) ,
FOREIGN KEY(customer_username) REFERENCES Customer ON DELETE set null ON UPDATE CASCADE,
FOREIGN KEY(vendor_username) REFERENCES Vendor ON DELETE NO ACTION ON UPDATE NO ACTION,
FOREIGN KEY(customer_order_id) REFERENCES Orders ON DELETE NO ACTION ON UPDATE NO ACTION
);
--CustomerAddstoCartProduct
CREATE TABLE CustomerAddstoCartProduct(
serial_no int,
customer_name varchar(20),
PRIMARY KEY (serial_no, customer_name) ,
FOREIGN KEY(customer_name) REFERENCES Customer ON DELETE NO ACTION ON UPDATE NO ACTION,
FOREIGN KEY(serial_no) REFERENCES Product ON DELETE NO ACTION ON UPDATE CASCADE
);
--Todays_Deals
CREATE TABLE Todays_Deals(
deal_id INT IDENTITY,
deal_amount INT,
[expiry_date] DATETIME,
admin_username VARCHAR(20),
PRIMARY KEY(deal_id),
FOREIGN KEY(admin_username) REFERENCES Admins ON DELETE set null ON UPDATE CASCADE,--check
);
--Todays_Deals_Product
CREATE TABLE Todays_Deals_Product( 
deal_id int ,
serial_no int,
PRIMARY KEY(deal_id, serial_no),
FOREIGN KEY(deal_id) REFERENCES Todays_Deals ON DELETE CASCADE ON UPDATE CASCADE,
FOREIGN KEY(serial_no) REFERENCES Product ON DELETE NO ACTION ON UPDATE NO ACTION
);
--offer
CREATE TABLE Offer(
offer_id INT IDENTITY, 
offer_amount decimal(10,2), 
[expiry_date] datetime,
PRIMARY KEY(offer_id)
);
--offerson product
CREATE TABLE OffersOnProduct( 
offer_id INT, 
serial_no INT,
FOREIGN KEY(offer_id) REFERENCES Offer ON DELETE CASCADE ON UPDATE CASCADE,
FOREIGN KEY(serial_no) REFERENCES Product ON DELETE CASCADE ON UPDATE CASCADE,
PRIMARY KEY (offer_id,serial_no));
--CUSTOMER QUEST.
CREATE TABLE Customer_Question_Product( 
serial_no INT,
customer_name VARCHAR(20),
question VARCHAR(50),
answer VARCHAR(50),
FOREIGN KEY (serial_no) REFERENCES Product ON DELETE CASCADE ON UPDATE CASCADE,
PRIMARY KEY(serial_no, customer_name),
FOREIGN KEY (customer_name) REFERENCES Customer ON DELETE NO ACTION ON UPDATE NO ACTION
);
--Wishlist
CREATE TABLE Wishlist( 
username varchar(20),
[name] varchar(20),
PRIMARY KEY (username,[name]),
FOREIGN KEY (username) REFERENCES Customer ON DELETE CASCADE ON UPDATE CASCADE
);

--wish list product
CREATE TABLE Wishlist_Product( 
username varchar(20), 
wish_name varchar(20), 
serial_no int ,
PRIMARY KEY (username,wish_name,serial_no),
FOREIGN KEY (username,wish_name) REFERENCES Wishlist ON DELETE CASCADE ON UPDATE CASCADE,
FOREIGN KEY (serial_no) REFERENCES Product ON DELETE NO ACTION ON UPDATE NO ACTION
);
--Admin_Customer_Giftcard
CREATE TABLE Admin_Customer_Giftcard( 
code VARCHAR(10),
customer_name VARCHAR(20),
admin_username VARCHAR(20) ,
remaining_points INT,
PRIMARY KEY(code,customer_name,admin_username),
FOREIGN KEY (code) REFERENCES GiftCard ON DELETE CASCADE ON UPDATE CASCADE,
FOREIGN KEY (customer_name) REFERENCES Customer ON DELETE NO ACTION ON UPDATE NO ACTION,
FOREIGN KEY (admin_username) REFERENCES Admins ON DELETE NO ACTION ON UPDATE NO ACTION
);
--Admin_Delivery_Order
CREATE TABLE Admin_Delivery_Order( 
delivery_username VARCHAR(20),
order_no INT,
admin_username VARCHAR(20),
delivery_window VARCHAR(50),--CHECK
PRIMARY KEY(delivery_username,order_no),
FOREIGN KEY (order_no) REFERENCES Orders ON DELETE CASCADE ON UPDATE CASCADE,
FOREIGN KEY (delivery_username) REFERENCES Delivery_person ON DELETE NO ACTION ON UPDATE NO ACTION,
FOREIGN KEY(admin_username) References Admins ON DELETE NO ACTION ON UPDATE NO ACTION);--CHECK 
--CUSTOMER credit card
CREATE TABLE Customer_CreditCard( 
customer_name VARCHAR(20),
cc_number VARCHAR(20),
PRIMARY KEY(customer_name, cc_number),
FOREIGN KEY (customer_name) REFERENCES Customer ON DELETE CASCADE ON UPDATE CASCADE,
FOREIGN KEY(cc_number) References Credit_Card ON DELETE CASCADE ON UPDATE CASCADE
);--CHECK 
--User Stories b
