﻿----ALTER PROC recommmend
----@customername varchar(20)
----AS
----SELECT *
----FROM Product
----WHERE serial_no IN(
----SELECT DISTINCT TOP 3 W.serial_no
----FROM CustomerAddstoCartProduct C1 INNER JOIN CustomerAddstoCartProduct C2 ON C1.serial_no = C2.serial_no INNER JOIN Wishlist_Product W ON W.username = C2.customer_name
----WHERE C1.customer_name=@customername AND C1.customer_name <> C2.customer_name
----EXCEPT(SELECT serial_no FROM CustomerAddstoCartProduct WHERE customer_name=@customername)
----UNION(
----SELECT DISTINCT TOP 3 P2.serial_no
----FROM Product P2 INNER JOIN Wishlist_Product W ON P2.serial_no=W.serial_no
----WHERE P2.category IN (SELECT DISTINCT TOP 3 P.category
----FROM CustomerAddstoCartProduct C INNER JOIN Product P ON C.serial_no = P.serial_no
----WHERE C.customer_name = @customername)
----EXCEPT(SELECT serial_no FROM CustomerAddstoCartProduct WHERE customer_name=@customername)
----))

--ALTER PROC recommend
--@customername VARCHAR(20)
--AS

----top 3 products
--SELECT TOP 3 serial_no
--FROM Wishlist_Product W,Product P
--WHERE W.serial_no = P.serial_no AND customer_username<>@customername AND serial_no NOT IN 
--(SELECT serial_no
--FROM CustomerAddstoCartProduct
--WHERE customer_name=@customername
--) AND P.category IN 
--(SELECT TOP 3 category
--FROM CustomerAddstoCartProduct C,Product P
--WHERE C.serial_no=P.serial_no AND C.customer_name=@customername
--GROUP BY category
--ORDER BY COUNT(category) DESC
--)
--GROUP BY serial_no
--ORDER BY COUNT(serial_no) DESC


----mywishlist
--SELECT 
--FROM Wishlist_Product
--WHERE username=@

----mycart
--SELECT serial_no
--FROM CustomerAddstoCartProduct
--WHERE customer_name=@customername

----TOP 3 categories
--SELECT TOP 3 category,COUNT(category) AS Catfreq 
--FROM CustomerAddstoCartProduct C,Product P
--WHERE C.serial_no=P.serial_no AND C.customer_name='ahmed.ashraf'
--GROUP BY category
--ORDER BY freq DESC

----most similar customers
--SELECT TOP 3 C2.customer_name, COUNT(customer_name) AS mostsim
--FROM CustomerAddstoCartProduct C1, CustomerAddstoCartProduct C2
--WHERE C1.customer_name=@customername AND C2.customer_name<>C1.customer_name AND C2.serial_no = C1.serial_no
--GROUP BY customer_name
--ORDER BY mostsim DESC


----most wished prod
--SELECT TOP 3 serial_no
--FROM Wishlist_Product W
--WHERE W.username<>@customername AND W.username IN 
--(SELECT TOP 3 C2.customer_name, COUNT(customer_name) AS mostsim
--FROM CustomerAddstoCartProduct C1, CustomerAddstoCartProduct C2
--WHERE C1.customer_name=@customername AND C2.customer_name<>C1.customer_name AND C2.serial_no = C1.serial_no
--GROUP BY customer_name
--ORDER BY mostsim DESC
--) AND serial_no NOT IN (SELECT serial_no
--FROM CustomerAddstoCartProduct
--WHERE customer_name=@customername
--)
--GROUP BY serial_no
--ORDER BY COUNT(serial_no)




GO
CREATE PROC postProduct 
@vendorUsername varchar(20), 
@product_name varchar(20) ,
@category varchar(20),
@product_description text ,
@price decimal(10,2),
@color varchar(20)
AS
INSERT INTO Product(product_name,category,product_description,price,color,vendor_username,available,final_price)
VALUES(@product_name,@category,@product_description,@price,@color,@vendorUsername,'1',@price)
----b
GO
CREATE PROC vendorviewProducts
@vendorname varchar(20)
AS
SELECT P.*
FROM Vendor V INNER JOIN Product P ON V.username=P.vendor_username
WHERE V.username=@vendorname
----c
GO
CREATE PROC EditProduct
@vendorname varchar(20),
@serialnumber int,
@product_name varchar(20) ,
@category varchar(20),
@product_description text , 
@price decimal(10,2),
@color varchar(20)
AS 
IF(@product_name IS NOT NULL)
UPDATE Product
SET product_name=@product_name
WHERE serial_no=@serialnumber AND vendor_username=@vendorname
IF(@category IS NOT NULL)
UPDATE Product
SET category=@category
WHERE serial_no=@serialnumber AND vendor_username=@vendorname
IF(@product_description IS NOT NULL)
UPDATE Product
SET product_description=@product_description
WHERE serial_no=@serialnumber AND vendor_username=@vendorname
IF(@price IS NOT NULL)
UPDATE Product
SET price=@price
WHERE serial_no=@serialnumber AND vendor_username=@vendorname
IF(@color IS NOT NULL)
UPDATE Product
SET color=@color
WHERE serial_no=@serialnumber AND vendor_username=@vendorname

----d
GO
CREATE PROC deleteProduct
@vendorname varchar(20),
@serialnumber int
AS
DELETE FROM Product 
WHERE vendor_username=@vendorname AND serial_no=@serialnumber
EXEC vendorviewProducts @vendorname
----e
GO
CREATE PROC viewQuestions
@vendorname varchar(20)
AS
SELECT CQP.*
FROM Customer_Question_Product CQP INNER JOIN Product P ON CQP.serial_no=P.serial_no
WHERE P.vendor_username=@vendorname
----f
GO
CREATE PROC answerQuestions
@vendorname varchar(20),
@serialno int,
@customername varchar(20),
@answer text
AS
UPDATE Customer_Question_Product
SET answer=@answer
WHERE serial_no=@serialno AND customer_name=@customername 
----G
-----Gi
GO
CREATE PROC addOffer
@offeramount int,
@expiry_date datetime
AS
INSERT INTO Offer(offer_amount,expiry_date) VALUES(@offeramount,@expiry_date)
-----Gii
GO 
CREATE PROC checkOfferonProduct
@serial int,
@activeoffer bit OUTPUT
AS
IF(@serial IN(SELECT serial_no FROM OffersOnProduct))
BEGIN
SET @activeoffer = '1';
END
ELSE
BEGIN 
SET @activeoffer = '0';
END
-----Giii
GO
CREATE PROC checkandremoveExpiredoffer
@offerid int
AS
IF((SELECT [expiry_date] FROM Offer WHERE offer_id=@offerid)<CURRENT_TIMESTAMP)
BEGIN
UPDATE Product 
SET final_price=price
FROM Product P INNER JOIN OffersOnProduct O ON P.serial_no=O.serial_no
WHERE O.offer_id=@offerid
DELETE FROM Offer
WHERE offer_id=@offerid
END
-----Giv
GO 
CREATE PROC applyOffer 
@vendorname varchar(20),
@offerid int,
@serial int
AS
DECLARE @prec decimal(10,2)
SELECT @prec=offer_amount/100
FROM Offer
WHERE offer_id=@offerid
IF(@serial NOT IN (SELECT serial_no FROM OffersOnProduct))
BEGIN
UPDATE PRODUCT 
SET final_price=price-(price*@prec)
WHERE vendor_username=@vendorname AND serial_no=@serial
INSERT INTO offersOnProduct VALUES(@offerid,@serial)
END
ELSE
PRINT 'The product has an active offer'
--ADMIN fun page 6
---a)
GO
CREATE PROC activateVendors
@admin_username varchar(20),
@vendor_username varchar(20)
AS
UPDATE Vendor
SET admin_username=@admin_username,activated='1'
WHERE username=@vendor_username
---b)
GO
CREATE PROC inviteDeliveryPerson
@delivery_username varchar(20),
@delivery_email varchar(50)
AS 
INSERT INTO Users (username,email)VALUES(@delivery_username,@delivery_email)
INSERT INTO Delivery_person VALUES(@delivery_username,'0')
---c)
GO 
CREATE PROC reviewOrders
AS
SELECT *
FROM Orders
---d)
GO 
CREATE PROC updateOrderStatusInProcess
@order_no int
AS
UPDATE Orders
SET order_status='in process'
WHERE order_no=@order_no