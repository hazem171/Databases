﻿--my proc PAGES 3 AND 4
GO
CREATE PROC showWishlistProduct
@customername varchar(20),
@name varchar(20)
AS
SELECT P.product_name,p.product_description,p.price,p.final_price,p.color
FROM Wishlist_Product WP INNER JOIN Product P ON WP.serial_no=P.serial_no


GO
ALTER PROC viewMyCart
@customer varchar(20)
AS
SELECT P.product_name,p.product_description,p.price,p.final_price,p.color
FROM CustomerAddstoCartProduct WP INNER JOIN Product P ON WP.serial_no=P.serial_no
WHERE customer_name =@customer

--check it 
GO 
CREATE PROC calculatepriceOrder
@customername varchar(20),
@sum decimal(10,2) OUTPUT
AS

SELECT @sum = SUM(P.final_price) FROM CustomerAddstoCartProduct C
inner join Product P ON C.serial_no=P.serial_no
WHERE c.customer_name=@customername
INSERT INTO Orders (total_amount,order_status,customer_name,order_date)
VALUES(@sum,'not processed',@customername,CURRENT_TIMESTAMP)


--productsinorder check it

GO
CREATE PROC productsinorder
@customername varchar(20),
@orderID int
AS
SELECT p.product_name,p.product_description,p.price,p.final_price,p.color
FROM CustomerAddstoCartProduct C
inner join Product P ON P.serial_no=C.serial_no
WHERE customer_name =@customername
UPDATE Product 
SET available ='0',customer_username=@customername,customer_order_id=@orderID
FROM Product P , CustomerAddstoCartProduct C
WHERE P.serial_no = C.serial_no AND C.customer_name = @customername
delete FROM CustomerAddstoCartProduct
WHERE customer_name<>@customername AND customer_name IN(SELECT C.customer_name FROM Product p INNER JOIN CustomerAddstoCartProduct C ON P.serial_no=C.serial_no WHERE C.customer_name <> @customername) 

 --empty cart
 
 GO
 CREATE PROC emptyCart
 @customername varchar(20)
 AS
 DELETE FROM CustomerAddstoCartProduct 
 WHERE customer_name =@customername 

 
 GO
 CREATE PROC makeOrder
 @customername varchar(20)
 AS
 DECLARE @sum DECIMAL(10,2)
 DECLARE @id INT
 EXEC calculatepriceOrder @customername,@sum
 SELECT @id = order_no
 FROM Orders
 WHERE @customername=customer_name
 EXEC productsinorder @customername, @id
 EXEC emptyCart @customername


 --CHECK FOR ALL CASES WHEN U FINISH GIFTCARD

GO 
CREATE PROC cancelOrder
@orderid int
AS
DECLARE @total DECIMAL(10,2)
DECLARE @totalcash DECIMAL(10,2)
DECLARE @totalcredit DECIMAL(10,2)
DECLARE @giftcode INT
DECLARE @disc INT 
DECLARE @ptype VARCHAR(20),@user VARCHAR(20)
SELECT @ptype=payment_type,@giftcode=Gift_Card_code_used,@total=total_amount,@totalcash=cash_amount,@totalcredit=credit_amount,@user=customer_name
FROM Orders WHERE @orderid=order_no
IF((SELECT [expiry_date] FROM Giftcard WHERE @giftcode = code)<CURRENT_TIMESTAMP)
BEGIN
UPDATE Orders 
SET total_amount=0
WHERE @orderid = order_no
UPDATE Product
SET available='1',customer_username=NULL,customer_order_id=NULL
WHERE @orderid=customer_order_id
IF(@ptype='credit')
SET @disc = @total-@totalcredit
IF(@ptype='cash')
SET @disc = @total-@totalcash
UPDATE Admin_Customer_Giftcard
SET remaining_points = remaining_points + @disc
WHERE @giftcode=code
UPDATE Customer
SET points = points + @disc
END
ELSE
BEGIN
UPDATE Orders 
SET total_amount=0
WHERE @orderid=order_no
UPDATE Product
SET available='1',customer_username=NULL,customer_order_id=NULL
WHERE @orderid=customer_order_id
END
DELETE FROM Orders
WHERE @orderid=order_no

GO
CREATE PROC returnProduct
@serialno int,
@orderid int
AS
DECLARE @total DECIMAL(10,2)
DECLARE @totalcash DECIMAL(10,2)
DECLARE @totalcredit DECIMAL(10,2)
DECLARE @giftcode INT
DECLARE @disc INT 
DECLARE @ptype VARCHAR(20)
SELECT @ptype=payment_type,@giftcode=Gift_Card_code_used,@total=total_amount,@totalcash=cash_amount,@totalcredit=credit_amount 
FROM Orders WHERE @orderid=order_no
IF(@total-@totalcash=0 OR @total-@totalcredit=0)
BEGIN
UPDATE Orders 
SET total_amount=0
WHERE @orderid = order_no
UPDATE Product
SET available='1',customer_username=NULL,customer_order_id=NULL
WHERE @serialno=serial_no
END
ELSE
BEGIN
IF((SELECT [expiry_date] FROM Giftcard WHERE @giftcode = code)<CURRENT_TIMESTAMP)
BEGIN
UPDATE Orders 
SET total_amount=0
WHERE @orderid = order_no
UPDATE Product
SET available='1',customer_username=NULL,customer_order_id=NULL
WHERE @serialno=serial_no
IF(@ptype='credit')
SET @disc = @total-@totalcredit
IF(@ptype='cash')
SET @disc = @total-@totalcash
UPDATE Admin_Customer_Giftcard
SET remaining_points = remaining_points + @disc
WHERE @giftcode=code
UPDATE Customer
SET points = points + @disc
END
ELSE
BEGIN
UPDATE Orders 
SET total_amount=0
WHERE @orderid = order_no
UPDATE Product
SET available='1',customer_username=NULL,customer_order_id=NULL
WHERE @serialno=serial_no
END
END

 --ShowproductsIbought
 GO
 CREATE PROC ShowproductsIbought
 @customername varchar(20)
 AS
 SELECT  serial_no ,product_name,category,product_description,price ,final_price,color 
 from Orders INNER JOIN Product ON customer_name=customer_username
 where customer_name=@customername



 --RATE
 GO 
 CREATE PROC rate
 @serialno int, 
 @rate int ,
 @customername varchar(20)
AS
UPDATE Product
SET rate=@rate
FROM Orders INNER JOIN Product ON customer_name=customer_username
WHERE serial_no=@serialno AND customer_username=@customername


--SpecifyAmount
GO
CREATE PROC SpecifyAmount
@customername varchar(20),
@orderID int, 
@cash decimal(10,2), 
@credit decimal(10,2)
AS
DECLARE @paid DECIMAL(10,2),@tot DECIMAL(10,2)
IF(@credit IS NULL OR @credit=0)
BEGIN
SET @paid=@cash
UPDATE Orders
SET payment_type='cash', cash_amount=@paid
WHERE @orderID = order_no
END
IF(@cash IS NULL OR @cash=0)
BEGIN
SET @paid=@credit
UPDATE Orders
SET payment_type='credit', credit_amount=@paid
WHERE @orderID = order_no
END
SELECT @tot = total_amount
FROM Orders
WHERE @orderID = order_no
IF(@tot>@paid)
BEGIN
--IF((@tot-@paid)<=(SELECT points FROM Customer WHERE @customername=username))
UPDATE Admin_Customer_Giftcard
SET remaining_points = remaining_points - (@tot-@paid)
WHERE @customername = customer_name
UPDATE Customer
SET points = points - (@tot - @paid)
WHERE @customername = username
END

--AddCreditCard

GO 
CREATE PROC AddCreditCard
@creditcardnumber varchar(20), 
@expirydate date , 
@cvv varchar(4), 
@customername varchar(20)
AS
INSERT INTO Credit_Card VALUES(@creditcardnumber,@expirydate,@cvv)
INSERT INTO Customer_CreditCard VALUES(@customername,@creditcardnumber)

--ChooseCreditCard
GO 
CREATE PROC ChooseCreditCard 
@creditcard varchar(20), 
@orderid int 
AS
UPDATE Orders
SET creditCard_number=@creditcard
WHERE order_no=@orderid


--pag 4
--r)
GO 
CREATE PROC viewDeliveryTypes
AS
SELECT D.type,d.time_duration,d.fees
FROM Delivery D
--s)
GO 
CREATE PROC specifydeliverytype
@orderID int, 
@deliveryID int
AS
DECLARE @time INT
SELECT @time=time_duration
FROM Delivery
WHERE id=@deliveryID
UPDATE Orders
SET remaining_days=@time ,delivery_id=@deliveryID
WHERE order_no=@orderID
--t)
GO
CREATE PROC trackRemainingDays
@orderid int, 
@customername varchar(20),
@days int OUTPUT
AS
SELECT @days=O.remaining_days
FROM Orders O
WHERE O.order_no=@orderID AND O.customer_name=@customername

