﻿--Page 1
go
CREATE PROC customerRegister
@username varchar(20),
@first_name varchar(20),
@last_name varchar(20),
@password varchar(20),
@email varchar(50)
AS
INSERT INTO Users Values (@username,@password,@first_name,@last_name,@email)
INSERT INTO Customer Values (@username,0)

go
CREATE PROC vendorRegister
@username varchar(20),
@first_name varchar(20),
@last_name varchar(20),
@password varchar(20),
@email varchar(50),
@company_name varchar(20),
@bank_acc_no varchar(20)
AS
INSERT INTO Users VALUES (@username,@password,@first_name,@last_name,@email)
INSERT INTO Vendor Values (@username,'0', @company_name, @bank_acc_no,null)


--REVIEW LATER
go
ALTER PROC userLogin
@username varchar(20),
@password varchar(20),
@success bit OUTPUT,
@type smallint OUTPUT
AS

IF (EXISTS ( SELECT U.username , U.[password]  FROM Users U WHERE (U.username=@username AND U.[password]=@password ))) 
BEGIN
SET @success ='1'
IF EXISTS (SELECT C.username from Customer C where C.username=@username)
SET @type =0
IF EXISTS (SELECT V.username from Vendor V where V.username=@username)
SET @type =1
IF EXISTS (SELECT A.username from Admins A where A.username=@username)
SET @type =2
IF EXISTS (SELECT D.username from Delivery_Person D where D.username=@username)
SET @type =3
END
ELSE
BEGIN
SET @success = '0'
SET @type ='-1'
END


go
CREATE PROC  addMobile
@username varchar(20),
@mobile_number varchar(20)
AS
IF EXISTS (SELECT  U.username From Users U WHERE U.username=@username)
Insert Into User_mobile_numbers Values (@mobile_number,@username)

go
CREATE PROC  addAddress
@username varchar(20),
@address varchar(100)
AS
IF EXISTS (SELECT  U.username From Users U WHERE U.username=@username)
Insert Into User_Addresses Values (@address,@username)

go
CREATE PROC showProducts
AS
select product_name,product_description,price,final_price,color from Product
WHERE available='1'

GO
CREATE PROC ShowProductsbyPrice
AS
SELECT product_name,product_description,price,final_price,color FROM product P
WHERE available='1'
ORDER BY P.price

GO
CREATE PROC searchbyname
@text varchar(20)
AS
SELECT product_name,product_description,price,final_price,color FROM Product P
where P.product_name LIKE '%'+@text+'%' AND available='1'

go
CREATE PROC AddQuestion
@serial int,
@customer varchar(20),
@Question varchar(50)
AS
INSERT INTO Customer_Question_Product Values(@serial , @customer, @Question,null)

GO
CREATE PROC addToCart
@customername varchar(20),
@serial int
AS
INSERT INTO CustomerAddstoCartProduct VALUES (@serial,@customername)

go
CREATE PROC  removefromCart
@customername varchar(20),
@serial int
AS
DELETE FROM CustomerAddstoCartProduct 
where customer_name = @customername AND serial_no = @serial

go
CREATE PROC  createWishlist
@customername varchar(20),
@name varchar(20)
AS
INSERT INTO Wishlist Values (@customername,@name)

GO
CREATE PROC AddtoWishlist
@customername varchar(20),
@wishlistname varchar(20),
@serial int
AS
INSERT INTO Wishlist_Product VALUES (@customername,@wishlistname,@serial)

GO
CREATE PROC removefromWishlist
@customername varchar(20),
@wishlistname varchar(20),
@serial int
AS
DELETE FROM Wishlist_Product
WHERE serial_no = @serial AND username = @customername AND @wishlistname=wish_name
