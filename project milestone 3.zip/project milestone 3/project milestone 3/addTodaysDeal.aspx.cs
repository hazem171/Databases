﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;

namespace project_milestone_3
{
    public partial class addTodaysDeal : System.Web.UI.Page
    {
        protected void addOnProduct(object sender, EventArgs e)
        {
            //Get the information of the connection to the database
            string connStr = ConfigurationManager.ConnectionStrings["MyDbConn"].ToString();

            //create a new connection
            SqlConnection conn = new SqlConnection(connStr);

            /*create a new SQL command which takes as parameters the name of the stored procedure and
             the SQLconnection name*/
            SqlCommand cmd = new SqlCommand("addTodaysDealOnProduct", conn);
            cmd.CommandType = CommandType.StoredProcedure;

            //To read the input from the user
            string deal_id = txt_deal_id.Text;
            string serial_no = txt_serial_no.Text;

            //pass parameters to the stored procedure
            cmd.Parameters.Add(new SqlParameter("@deal_id", deal_id));
            cmd.Parameters.Add(new SqlParameter("@serial_no", serial_no));

            //Save the output from the procedure
            SqlCommand cmd2 = new SqlCommand("checkTodaysDealOnProduct", conn);
            cmd2.CommandType = CommandType.StoredProcedure;
            cmd2.Parameters.Add(new SqlParameter("@deal_id", deal_id));
            SqlParameter activeDeal = cmd2.Parameters.Add("@activeDeal", SqlDbType.Int);
            activeDeal.Direction = ParameterDirection.Output;
            try
            {
                conn.Open();
                cmd2.ExecuteNonQuery();
                conn.Close();



                if (!(activeDeal.Value.ToString().Equals("1")))
                {
                    //Executing the SQLCommand
                    conn.Open();
                    cmd.ExecuteNonQuery();
                    conn.Close();
                    Response.Write("Today's deal been added sucessfully!");


                }
                else
                {
                    Response.Write("product already has a Today's deal !");
                }
            }
            catch (SqlException)
            {
                Response.Write("please try again !");
            }
        }
        protected void ToMainTodaysDeal(object sender, EventArgs e)
        {
            Response.Redirect("TodaysDeal.aspx", true);
        }


    }
}