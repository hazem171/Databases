﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace project_milestone_3
{
    public partial class adminMain : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void addTelephoneNo(object sender, EventArgs e)
        {
            Response.Redirect("admintel.aspx", true);
        }
        protected void activateVendorPage(object sender, EventArgs e)
        {
            Response.Redirect("vendor_activation.aspx", true);
        }
        protected void reviewOrdersPage(object sender, EventArgs e)
        {
            Response.Redirect("reviewingOrders.aspx", true);
        }
        protected void addTodaysDealPage(object sender, EventArgs e)
        {
            Response.Redirect("TodaysDeal.aspx", true);
        }
        protected void returnLogin(object sender, EventArgs e)
        {
            Response.Redirect("Login.aspx", true);

        }
    }

}