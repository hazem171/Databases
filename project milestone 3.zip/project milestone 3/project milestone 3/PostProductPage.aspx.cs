﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;

namespace project_milestone_3
{
    public partial class PostProductPage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //Get the information of the connection to the database
            string connStr = ConfigurationManager.ConnectionStrings["MyDbConn"].ToString();

            //create a new connection
            SqlConnection conn = new SqlConnection(connStr);

            /*create a new SQL command which takes as parameters the name of the stored procedure and
             the SQLconnection name*/
            SqlCommand cmd = new SqlCommand("postProduct", conn);
            cmd.CommandType = CommandType.StoredProcedure;

            //To read the input from the user
            string vendorUsername = (String)(Session["field1"]);
            string product_name = txt_product_name.Text;
            string category = txt_category.Text;
            string product_description = txt_product_description.Text;
            string price = txt_price.Text;
            string color = txt_color.Text;

            //pass parameters to the stored procedure
            cmd.Parameters.Add(new SqlParameter("@vendorUsername", vendorUsername));
            cmd.Parameters.Add(new SqlParameter("@product_name", product_name));
            cmd.Parameters.Add(new SqlParameter("@category", category));
            cmd.Parameters.Add(new SqlParameter("@product_description", product_description));
            cmd.Parameters.Add(new SqlParameter("@price", price));
            cmd.Parameters.Add(new SqlParameter("@color", color));

            //Save the output from the procedure

            //Executing the SQLCommand
            try {
                conn.Open();
                cmd.ExecuteNonQuery();
                conn.Close();
                Response.Write("Product was posted successfully!");
            }
            catch (SqlException)
            {
                Response.Write("Product wasn't posted successfully!");
            }
        }

        
        protected void returnVendor(object sender, EventArgs e)
        {
            Response.Redirect("VendorMain.aspx", true);
        }
    }
}