﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;


namespace project_milestone_3
{
    public partial class OfferCreate : System.Web.UI.Page
    {
        protected void createOffer(object sender, EventArgs e)
        {
            //Get the information of the connection to the database
            string connStr = ConfigurationManager.ConnectionStrings["MyDbConn"].ToString();

            //create a new connection
            SqlConnection conn = new SqlConnection(connStr);

            /*create a new SQL command which takes as parameters the name of the stored procedure and
             the SQLconnection name*/
            SqlCommand cmd = new SqlCommand("addOffer", conn);
            cmd.CommandType = CommandType.StoredProcedure;

            //To read the input from the user
            int offeramount = Int32.Parse(txt_offer_amount.Text);
            string expiry_date = txt_expiry_date.Text;

            //pass parameters to the stored procedure
            cmd.Parameters.Add(new SqlParameter("@offeramount", offeramount));
            cmd.Parameters.Add(new SqlParameter("@expiry_date", expiry_date));
            //Executing the SQLCommand
            try
            {
                conn.Open();
                cmd.ExecuteNonQuery();
                conn.Close();
                Response.Write("Offer have been added sucessfully");

            }
            catch (SqlException)
            {
                Response.Write("please try again");

            }


        }
        protected void ToMainOffer(object sender, EventArgs e)
        {
            Response.Redirect("OfferPage.aspx", true);
        }
        protected void Page_Load(object sender, EventArgs e)
        {

        }
    }
}