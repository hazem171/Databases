﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
namespace project_milestone_3
{
    public partial class Vendor_Registration : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Register(object sender, EventArgs e)
        {
            //Get the information of the connection to the database
            string connStr = ConfigurationManager.ConnectionStrings["MyDbConn"].ToString();

            //create a new connection
            SqlConnection conn = new SqlConnection(connStr);

            /*create a new SQL command which takes as parameters the name of the stored procedure and
             the SQLconnection name*/
            SqlCommand cmd = new SqlCommand("vendorRegister", conn);
            cmd.CommandType = CommandType.StoredProcedure;

            //To read the input from the user
            string username = TextBox3.Text;
            string email = TextBox5.Text;
            string f = TextBox1.Text;
            string l = TextBox2.Text;
            string pass = TextBox6.Text;
            string bankno = TextBox7.Text;
            string compname = TextBox8.Text;

            //pass parameters to the stored procedure
            cmd.Parameters.Add(new SqlParameter("@username", username));
            cmd.Parameters.Add(new SqlParameter("@first_name", f));
            cmd.Parameters.Add(new SqlParameter("@last_name", l));
            cmd.Parameters.Add(new SqlParameter("@email", email));
            cmd.Parameters.Add(new SqlParameter("@password", pass));
            cmd.Parameters.Add(new SqlParameter("@bank_acc_no", bankno));
            cmd.Parameters.Add(new SqlParameter("@company_name", compname));




            //Save the output from the procedure

            //Executing the SQLCommand
            try
            {
                conn.Open();
                cmd.ExecuteNonQuery();
                conn.Close();
                Response.Write("Regestration successful");
                Response.Redirect("Login.aspx", true);

            }
            catch (SqlException e1)
            {
                Response.Write("Regestration failed");

            }

         
           
        }

    }
}