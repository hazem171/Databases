﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;


namespace project_milestone_3
{
    public partial class reviewingOrders : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string connStr = ConfigurationManager.ConnectionStrings["MyDbConn"].ToString();
            SqlConnection conn = new SqlConnection(connStr);

            SqlCommand cmd = new SqlCommand("reviewOrders", conn);
            cmd.CommandType = CommandType.StoredProcedure;

            conn.Open();

            //IF the output is a table, then we can read the records one at a time
            SqlDataReader rdr = cmd.ExecuteReader(CommandBehavior.CloseConnection);
           
        
            
            //this is how you retrive data from session variable.
            string field1 = (string)(Session["field1"]);
            
        }
        protected void updateOrder(object sender, EventArgs e)
        {
            //Get the information of the connection to the database
            string connStr = ConfigurationManager.ConnectionStrings["MyDbConn"].ToString();

            //create a new connection
            SqlConnection conn = new SqlConnection(connStr);

            /*create a new SQL command which takes as parameters the name of the stored procedure and
             the SQLconnection name*/
            SqlCommand cmd = new SqlCommand("updateOrderStatusInProcess", conn);
            cmd.CommandType = CommandType.StoredProcedure;

            //To read the input from the user
            string order_no = txt_order_no.Text;

            //pass parameters to the stored procedure
            cmd.Parameters.Add(new SqlParameter("@order_no", order_no));
            //Executing the SQLCommand
            try
            {
                conn.Open();
                cmd.ExecuteNonQuery();
                conn.Close();
                Response.Write("order status was updated correctly !");
                GridView1.DataBind();
            }
            catch (SqlException) 
            {
                Response.Write("order status wasn't updated correctly !");
                GridView1.DataBind();
            }
            

        }
        protected void adminMain(object sender, EventArgs e)
        {
            Response.Redirect("adminMain.aspx", true);
        }

        protected void TextBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}