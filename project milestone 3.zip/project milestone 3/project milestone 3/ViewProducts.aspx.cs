﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;


namespace project_milestone_3
{
    public partial class ViewProducts : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            //Get the information of the connection to the database
            string connStr = ConfigurationManager.ConnectionStrings["MyDbConn"].ToString();

            //create a new connection
            SqlConnection conn = new SqlConnection(connStr);

            /*create a new SQL command which takes as parameters the name of the stored procedure and
             the SQLconnection name*/
            SqlCommand cmd = new SqlCommand("ShowProductsbyPrice", conn);
            cmd.CommandType = CommandType.StoredProcedure;

           
                conn.Open();
                SqlDataReader rdr = cmd.ExecuteReader(CommandBehavior.CloseConnection);
                while (rdr.Read())
                {

                    string prodName = rdr.GetString(rdr.GetOrdinal("product_name"));
                    string productdescription = rdr.GetString(rdr.GetOrdinal("product_description"));
                    decimal proprice = rdr.GetDecimal(rdr.GetOrdinal("price"));
                    decimal proFinalprice = rdr.GetDecimal(rdr.GetOrdinal("final_price"));
                    string procolor = rdr.GetString(rdr.GetOrdinal("color"));

                    //Create a new label and add it to the HTML form

                    Label lbl_product = new Label();
                    lbl_product.Text = "prodName : " + prodName + " | ";
                    form1.Controls.Add(lbl_product);

                    Label lbl_ProductName = new Label();
                    lbl_ProductName.Text = "prodName : " + productdescription + " | ";
                    form1.Controls.Add(lbl_ProductName);

                    Label lbl_ProductPrice = new Label();
                    lbl_ProductPrice.Text ="proprice: "+ proprice + " | ";
                    form1.Controls.Add(lbl_ProductPrice);


                    Label lbl_ProductFinalPrice = new Label();
                    lbl_ProductFinalPrice.Text ="proFinalprice: "+ proFinalprice + " | ";
                    form1.Controls.Add(lbl_ProductFinalPrice);

                    Label lbl_ProductColor = new Label();
                    lbl_ProductColor.Text = "procolor: " + procolor + "<br /> <br />  ";
                    form1.Controls.Add(lbl_ProductColor);


                }
            
           

        }
        protected void returnCustomerHome(object sender, EventArgs e)
        {
            Response.Redirect("CustomerHome.aspx", true);
        }
    }
}