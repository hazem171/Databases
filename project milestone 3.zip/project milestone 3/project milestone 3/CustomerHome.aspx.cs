﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;


namespace project_milestone_3
{
    public partial class CustomerHome : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void addTelephoneNo(object sender, EventArgs e)
        {
            Response.Redirect("custtel.aspx", true);
        }
        protected void viewProducts(object sender, EventArgs e)
        {
            Response.Redirect("ViewProducts.aspx", true);

        }

        protected void RemoveFromCart(object sender, EventArgs e)
        {
            string connStr = ConfigurationManager.ConnectionStrings["MyDbConn"].ToString();
            SqlConnection conn = new SqlConnection(connStr);

            string customer = (string)(Session["field1"]);
            try { 
            int serial = Int32.Parse(TextBox9.Text);

            SqlCommand cmd = new SqlCommand("removefromCart", conn);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.Add(new SqlParameter("@customername", customer));
            cmd.Parameters.Add(new SqlParameter("@serial", serial));
                conn.Open();
                cmd.ExecuteNonQuery();
                conn.Close();
                Response.Write("the product is removed from the cart succesfully");
            }
            catch (SqlException)
            {
                Response.Write("the product does not exist in cart");


            }
            catch (FormatException)
            {
                Response.Write("please add a serial number for the product");
            }

        }


        protected void AddToCart(object sender, EventArgs e)
        {
            string connStr = ConfigurationManager.ConnectionStrings["MyDbConn"].ToString();
            SqlConnection conn = new SqlConnection(connStr);

            string customer = (string)(Session["field1"]);
            try
            {
            int serial = Int32.Parse(TextBox9.Text);
            
            SqlCommand cmd = new SqlCommand("addToCart", conn);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.Add(new SqlParameter("@customername", customer));
            cmd.Parameters.Add(new SqlParameter("@serial", serial));



            
                conn.Open();
                cmd.ExecuteNonQuery();
                conn.Close();
                Response.Write("the product is added to cart");
            }
            catch (SqlException ex)
            {
                Response.Write(ex.Number);


            }
            catch (FormatException)
            {
                Response.Write("please add a valid product");
            }

        }

        protected void removefromWishlist(object sender, EventArgs e)
        {


            string connStr = ConfigurationManager.ConnectionStrings["MyDbConn"].ToString();
            SqlConnection conn = new SqlConnection(connStr);

            string customer = (string)(Session["field1"]);
            string wishlistname = TextBox5.Text;
            try { 
            int serial = Int32.Parse(TextBox6.Text);
            SqlCommand cmd = new SqlCommand("removefromWishlist", conn);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.Add(new SqlParameter("@customername", customer));
            cmd.Parameters.Add(new SqlParameter("@wishlistname", wishlistname));
            cmd.Parameters.Add(new SqlParameter("@serial", serial));

                conn.Open();
                cmd.ExecuteNonQuery();
                conn.Close();
                Response.Write("the product is removed from wishlist succesfully");
            }
            catch (SqlException ex)
            {
                Response.Write(ex.Number);

            }
            catch (FormatException)
            {
                Response.Write("please remove a valid product");
            }

        }

        protected void AddTowishlist(object sender, EventArgs e)
        {

            string connStr = ConfigurationManager.ConnectionStrings["MyDbConn"].ToString();
            SqlConnection conn = new SqlConnection(connStr);

            string customer = (string)(Session["field1"]);
            string wishlistname = TextBox5.Text;
            try
            {
                int serial = Int32.Parse(TextBox6.Text);
                SqlCommand cmd = new SqlCommand("AddtoWishlist", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                Response.Write(wishlistname); Response.Write(serial);
                cmd.Parameters.Add(new SqlParameter("@customername", customer));
                cmd.Parameters.Add(new SqlParameter("@wishlistname", wishlistname));
                cmd.Parameters.Add(new SqlParameter("@serial", serial));




                conn.Open();
                cmd.ExecuteNonQuery();
                conn.Close();
                Response.Write("the product is added to wishlist succesfully");
            }
            catch (SqlException)
            {
                Response.Write("the product is not in the wishlist");
            }
            catch (FormatException)
            {
                Response.Write("please add a product");
            }
            

        }
        protected void LoadList(object sender, EventArgs e)
        {
            DataTable orders = new DataTable();
            string connStr = ConfigurationManager.ConnectionStrings["MyDbConn"].ToString();
            SqlConnection conn = new SqlConnection(connStr);

            SqlDataAdapter adapter = new SqlDataAdapter("SELECT order_no FROM MIL2.dbo.Orders WHERE customer_name= @name ", connStr);
            string c = (string)(Session["field1"]);
            adapter.SelectCommand.Parameters.AddWithValue("@name", c);
            adapter.Fill(orders);
            ords.ClearSelection();
            ords.DataSource = orders;
            ords.DataTextField = "order_no";
            ords.DataValueField = "order_no";
            ords.DataBind();
            ords.Items.Insert(0, new ListItem("<Select Order>", "0"));

        }

        protected void LoadList0(object sender, EventArgs e)
        {
            DataTable orders = new DataTable();
            string connStr = ConfigurationManager.ConnectionStrings["MyDbConn"].ToString();
            SqlConnection conn = new SqlConnection(connStr);

            SqlDataAdapter adapter = new SqlDataAdapter("SELECT order_no FROM MIL2.dbo.Orders WHERE customer_name= @name ", connStr);
            string c = (string)(Session["field1"]);
            adapter.SelectCommand.Parameters.AddWithValue("@name", c);
            adapter.Fill(orders);
            ords0.ClearSelection();
            ords0.DataSource = orders;
            ords0.DataTextField = "order_no";
            ords0.DataValueField = "order_no";
            ords0.DataBind();
            ords0.Items.Insert(0, new ListItem("<Select Order>", "0"));

        }

        protected void LoadList1(object sender, EventArgs e)
        {
            DataTable orders = new DataTable();
            string connStr = ConfigurationManager.ConnectionStrings["MyDbConn"].ToString();

            SqlConnection conn = new SqlConnection(connStr);
            SqlDataAdapter adapter = new SqlDataAdapter("SELECT order_no FROM MIL2.dbo.Orders WHERE customer_name= @name AND (order_status='in process' OR order_status= 'not processed')", connStr);
            string c = (string)(Session["field1"]);
            adapter.SelectCommand.Parameters.AddWithValue("@name", c);
            adapter.Fill(orders);

            ords1.DataSource = orders;
            ords1.DataTextField = "order_no";
            ords1.DataValueField = "order_no";
            ords1.DataBind();
            ords1.Items.Insert(0, new ListItem("<Select Order>", "0"));

        }
        protected void useCredit(object sender, EventArgs e)
        {
            string connStr = ConfigurationManager.ConnectionStrings["MyDbConn"].ToString();
            SqlConnection conn = new SqlConnection(connStr);
            SqlCommand cmd = new SqlCommand("ChooseCreditCard", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add(new SqlParameter("@creditcard", cr.SelectedValue));
            cmd.Parameters.Add(new SqlParameter("@orderid", Int32.Parse(ords0.SelectedValue)));
            try
            {
                if (ords0.SelectedIndex == 0)
                {
                    Response.Write("Couldn't Select Credit Card");
                }
                else
                {
                    conn.Open();
                    cmd.ExecuteNonQuery();
                    conn.Close();
                    Response.Write("Credit Card Select Successfully");
                }
            }
            catch(SqlException) {
                Response.Write("Couldn't Select Credit Card");
            }
        }

        protected void cancelOrder(object sender, EventArgs e)
        {
            string connStr = ConfigurationManager.ConnectionStrings["MyDbConn"].ToString();
            SqlConnection conn = new SqlConnection(connStr);
            SqlCommand cmd = new SqlCommand("cancelOrder", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@orderid", SqlDbType.Int).Value = Int32.Parse(ords1.SelectedValue);
            try
            {
                if (ords1.SelectedIndex == 0)
                {
                    Response.Write("Couldn't Cancel Order");
                }
                else
                {
                    conn.Open();
                    cmd.ExecuteNonQuery();
                    conn.Close();
                    Response.Write("Order Cancelled");
                }
            }
            catch (SqlException)
            {
                Response.Write("Couldn't Cancel Order");
            }
        }

        protected void LoadCredit(object sender, EventArgs e)
        {
            DataTable cred = new DataTable();
            string connStr = ConfigurationManager.ConnectionStrings["MyDbConn"].ToString();

            SqlConnection conn = new SqlConnection(connStr);
            SqlDataAdapter adapter = new SqlDataAdapter("SELECT cc_number FROM MIL2.dbo.Customer_CreditCard WHERE customer_name= @name ", connStr);
            string c = (string)(Session["field1"]);
            adapter.SelectCommand.Parameters.AddWithValue("@name", c);
            adapter.Fill(cred);
            cr.ClearSelection();
            cr.DataSource = cred;
            cr.DataTextField = "cc_number";
            cr.DataValueField = "cc_number";
            cr.DataBind();
            cr.Items.Insert(0, new ListItem("<Select Credit Card>", "0"));

        }

        protected void makeOrder(object sender, EventArgs e)
        {
            string connStr = ConfigurationManager.ConnectionStrings["MyDbConn"].ToString();

            SqlConnection conn = new SqlConnection(connStr);

            SqlCommand cmd = new SqlCommand("makeOrder", conn);
            cmd.CommandType = CommandType.StoredProcedure;

            string usern = (string)(Session["field1"]);
            cmd.Parameters.Add(new SqlParameter("@customername", usern));
            try
            {
                conn.Open();
                cmd.ExecuteNonQuery();
                conn.Close();
                Response.Redirect("MakeOrder.aspx", true);
                
            }
            catch(SqlException)
            {
                Response.Write("Couldn't Add Order");
            }
        }

        protected void specifyAmount(object sender, EventArgs e)
        {
            string connStr = ConfigurationManager.ConnectionStrings["MyDbConn"].ToString();

            SqlConnection conn = new SqlConnection(connStr);

            SqlCommand cmd = new SqlCommand("SpecifyAmount", conn);
            cmd.CommandType = CommandType.StoredProcedure;

            string usern = (string)(Session["field1"]);
            int ord = Int32.Parse(ords.SelectedValue);
            try{
                int amount = Int32.Parse(amnt.Text);
            
            cmd.Parameters.Add(new SqlParameter("@customername", usern));
            cmd.Parameters.Add(new SqlParameter("@orderID", ord));
            if (ords.SelectedIndex == 0)
            {
                Response.Write("Order failed");
            }
            else
            {
                int z = 0;
                if (pcash.Checked)
                {
                    cmd.Parameters.Add(new SqlParameter("@cash", amount));
                    cmd.Parameters.Add(new SqlParameter("@credit", z));
                }
                else if (credit.Checked)
                {
                    cmd.Parameters.Add(new SqlParameter("@credit", amount));
                    cmd.Parameters.Add(new SqlParameter("@cash", z));
                }

                    conn.Open();
                    cmd.ExecuteNonQuery();
                    conn.Close();
                    Response.Write("Order Added");
            }
            }
                catch (SqlException)
                {
                    Response.Write("Order failed");
                }
                catch (FormatException)
                {
                    Response.Write("Order failed");
                }

            
        }


         protected void addCreditCard(object sender, EventArgs e)
        {
            string connStr = ConfigurationManager.ConnectionStrings["MyDbConn"].ToString();
            SqlConnection conn = new SqlConnection(connStr);
            try {  
            string customer = (string)(Session["field1"]);
            string creditcardnumber = TextBox2.Text;
            string cvv = TextBox3.Text;
            DateTime expiryDate = DateTime.ParseExact(TextBox4.Text,"dd/MM/yyyy",null);
            SqlCommand cmd = new SqlCommand("AddCreditCard", conn);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.Add(new SqlParameter("@customername", customer));
            cmd.Parameters.Add(new SqlParameter("@creditcardnumber", creditcardnumber));
            cmd.Parameters.Add(new SqlParameter("@cvv", cvv));
            cmd.Parameters.Add(new SqlParameter("@expirydate", expiryDate));
                conn.Open();
                cmd.ExecuteNonQuery();
                conn.Close();
                Response.Write("the credit card is added succesfully");
            }
            catch (SqlException)
            {
                Response.Write("the Credit card already exists");

            }
            catch (FormatException)
            {
                Response.Write("Enter a Credit Card Number");
            }

        }
    



        protected void createAwishlist(object sender, EventArgs e)
        {
            string connStr = ConfigurationManager.ConnectionStrings["MyDbConn"].ToString();
            SqlConnection conn = new SqlConnection(connStr);

            string customer = (string)(Session["field1"]);
            string name = TextBox1.Text; 
            SqlCommand cmd = new SqlCommand("createWishlist", conn);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.Add(new SqlParameter("@customername", customer));
            cmd.Parameters.Add(new SqlParameter("@name", name));


            try
            {
                conn.Open();
                cmd.ExecuteNonQuery();
                conn.Close();
                Response.Write("the wishlist is created succesfully");
            }
            catch (SqlException)
            {
                Response.Write("the wishlist already exists");


            }

        }
    }
}