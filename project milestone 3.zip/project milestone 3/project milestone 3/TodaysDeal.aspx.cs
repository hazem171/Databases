﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace project_milestone_3
{
    public partial class TodaysDeal : System.Web.UI.Page
    {
        protected void createDeal(object sender, EventArgs e)
        {
            Response.Redirect("TodaysDealCreate.aspx", true);
        }
        protected void adminMain(object sender, EventArgs e)
        {
            Response.Redirect("adminMain.aspx", true);
        }

        protected void addTodaysDealOnProduct(object sender, EventArgs e)
        {
            Response.Redirect("addTodaysDeal.aspx", true);
        }
        protected void removeExpired(object sender, EventArgs e)
        {
            Response.Redirect("removeTodaysDeal.aspx", true);
        }
    }
}