﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;

namespace project_milestone_3
{
    public partial class vendor_activation : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void activateVendor(object sender, EventArgs e)
        {
            //Get the information of the connection to the database
            string connStr = ConfigurationManager.ConnectionStrings["MyDbConn"].ToString();

            //create a new connection
            SqlConnection conn = new SqlConnection(connStr);

            /*create a new SQL command which takes as parameters the name of the stored procedure and
             the SQLconnection name*/
            SqlCommand cmd = new SqlCommand("activateVendors", conn);
            cmd.CommandType = CommandType.StoredProcedure;

            //To read the input from the user
            string adminUsername = (String)(Session["field1"]);
            string vendorUsername = txt_vendorUsername.Text;

            //pass parameters to the stored procedure
            cmd.Parameters.Add(new SqlParameter("@admin_username", adminUsername));
            cmd.Parameters.Add(new SqlParameter("@vendor_username", vendorUsername));
            //Executing the SQLCommand
            try
            {
                conn.Open();
                cmd.ExecuteNonQuery();
                conn.Close();
                Response.Write("activation is successfull");
            }
            catch (SqlException)
            {
                Response.Write("wrong admin or vendor username");
            }
        }
        protected void adminMain(object sender, EventArgs e)
        {
            Response.Redirect("adminMain.aspx", true);
        }
    }
}
