﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;



namespace project_milestone_3
{
    public partial class vendortel : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void addNumber(object sender, EventArgs e)
        {
            string connStr = ConfigurationManager.ConnectionStrings["MyDbConn"].ToString();
            SqlConnection conn = new SqlConnection(connStr);

            string customer = (string)(Session["field1"]);
            string number = TextBox1.Text;

            SqlCommand cmd = new SqlCommand("addMobile", conn);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.Add(new SqlParameter("@username", customer));
            cmd.Parameters.Add(new SqlParameter("@mobile_number", number));



            try
            {
                conn.Open();
                cmd.ExecuteNonQuery();
                conn.Close();
                Response.Write("the number is added");
            }
            catch (SqlException )
            {
                Response.Write("the number already exists");


            }

        }
        protected void returnCustomerHome(object sender, EventArgs e)
        {
            Response.Redirect("VendorMain.aspx", true);
        }
    }
}