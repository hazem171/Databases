﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace project_milestone_3
{
    public partial class offerPage : System.Web.UI.Page
    {
        protected void createOffer(object sender, EventArgs e)
        {
            Response.Redirect("OfferCreate.aspx", true);
        }
        protected void VendorMain(object sender, EventArgs e)
        {
            Response.Redirect("VendorMain.aspx", true);
        }

        protected void addOfferOnProduct(object sender, EventArgs e)
        {
            Response.Redirect("addOffer.aspx", true);
        }
        protected void removeExpired(object sender, EventArgs e)
        {
            Response.Redirect("removeOffer.aspx", true);
        }

       
    }
}