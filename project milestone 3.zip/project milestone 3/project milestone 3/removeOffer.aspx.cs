﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;


namespace project_milestone_3
{
    public partial class removeOffer : System.Web.UI.Page
    {
        protected void removeOffers(object sender, EventArgs e)
        {
            //Get the information of the connection to the database
            string connStr = ConfigurationManager.ConnectionStrings["MyDbConn"].ToString();

            //create a new connection
            SqlConnection conn = new SqlConnection(connStr);

            /*create a new SQL command which takes as parameters the name of the stored procedure and
             the SQLconnection name*/
            SqlCommand cmd = new SqlCommand("checkandremoveExpiredoffer", conn);
            cmd.CommandType = CommandType.StoredProcedure;

            //To read the input from the user
            string remove = txt_remove.Text;

            //pass parameters to the stored procedure
            cmd.Parameters.Add(new SqlParameter("@offerid", remove));
            
            try
            {
                
                    conn.Open();
                    cmd.ExecuteNonQuery();
                    conn.Close();
                    Response.Write("Deal is removed successfully!");
               
            }
            catch (SqlException)
            {
                Response.Write("please try again");
            }
            //Executing the SQLCommand

        }
        protected void ToMainOffer(object sender, EventArgs e)
        {
            Response.Redirect("offerPage.aspx", true);
        }
    }
}