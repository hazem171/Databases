﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;

namespace project_milestone_3
{
    public partial class VendorMain : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void addTelephoneNo(object sender, EventArgs e)
        {
            Response.Redirect("vendortel.aspx", true);
        }

        protected void PostProduct(object sender, EventArgs e)
        {
            Response.Redirect("PostProductPage.aspx", true);
        }
        protected void viewProducts(object sender, EventArgs e)
        {
            Response.Redirect("viewProductsPage.aspx", true);
        }
        protected void EditProducts(object sender, EventArgs e)
        {
            Response.Redirect("EditProductsPage.aspx", true);
        }
        protected void offer(object sender, EventArgs e)
        {
            Response.Redirect("offerPage.aspx", true);
        }
        protected void returnLogin(object sender, EventArgs e)
        {
            Response.Redirect("Login.aspx", true);

        }
    }
}