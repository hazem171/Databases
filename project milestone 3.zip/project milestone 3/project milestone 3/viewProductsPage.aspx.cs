﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;

namespace project_milestone_3
{
    public partial class viewProductsPage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string connStr = ConfigurationManager.ConnectionStrings["MyDbConn"].ToString();
            SqlConnection conn = new SqlConnection(connStr);

            SqlCommand cmd = new SqlCommand("vendorviewProducts", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            string vendorname = (string)(Session["Field1"]);
            cmd.Parameters.Add(new SqlParameter("@vendorname", vendorname));

            //conn.Open();

            ////IF the output is a table, then we can read the records one at a time
            //SqlDataReader rdr = cmd.ExecuteReader(CommandBehavior.CloseConnection);

            //while (rdr.Read())
            //{
            //    //Get the value of the attribute order_no in the order table
            //    string serial_no = rdr.GetInt32(rdr.GetOrdinal("serial_no")) + "";
            //    Label lbl_serial_no = new Label();
            //    lbl_serial_no.Text = "serial no: " + serial_no + "|";
            //    form1.Controls.Add(lbl_serial_no);

            //    string product_name = rdr.GetString(rdr.GetOrdinal("product_name"));
            //    Label lbl_product_name = new Label();
            //    lbl_product_name.Text= "product name: " + product_name + "|";
            //    form1.Controls.Add(lbl_product_name);

            //    string category = rdr.GetString(rdr.GetOrdinal("category")) + "";
            //    Label lbl_category = new Label();
            //    lbl_category.Text = "category: " + category + "|";
            //    form1.Controls.Add(lbl_category);

            //    string product_description = rdr.GetString(rdr.GetOrdinal("product_description")) + "";
            //    Label lbl_product_description = new Label();
            //    lbl_product_description.Text = "product_description " + product_description + "|";
            //    form1.Controls.Add(lbl_product_description);

            //    string price = rdr.GetDecimal(rdr.GetOrdinal("price")) + "";
            //    Label lbl_price = new Label();
            //    lbl_price.Text = "price " + price + "|";
            //    form1.Controls.Add(lbl_price);

            //    string final_price = rdr.GetDecimal(rdr.GetOrdinal("final_price")) + "";
            //    Label lbl_final_price = new Label();
            //    lbl_final_price.Text = "final_price " + final_price + "|";
            //    form1.Controls.Add(lbl_final_price);

            //    string color = rdr.GetString(rdr.GetOrdinal("color")) + "";
            //    Label lbl_color = new Label();
            //    lbl_color.Text = "color " + color + "|";
            //    form1.Controls.Add(lbl_color);

            //    string available = rdr.GetSqlBinary((rdr.GetOrdinal("available"))) + "";
            //    Label lbl_available = new Label();
            //    lbl_available.Text = "available " + available + "|";
            //    form1.Controls.Add(lbl_available);

            //    string rate = rdr.GetInt32(rdr.GetOrdinal("rate")) + "";
            //    Label lbl_rate = new Label();
            //    lbl_rate.Text = "rate " + rate + "|";
            //    form1.Controls.Add(lbl_rate);

            //    string vendor_username = rdr.GetString(rdr.GetOrdinal("vendor_username")) + "";
            //    Label lbl_vendor_username = new Label();
            //    lbl_vendor_username.Text = "vendor_username " + vendor_username + "|";
            //    form1.Controls.Add(lbl_vendor_username);

            //    //string customer_username = rdr.GetString(rdr.GetOrdinal("customer_username")) + "";
            //    //Label lbl_customer_username = new Label();
            //    //lbl_customer_username.Text = "customer_username " + customer_username + "|";
            //    //form1.Controls.Add(lbl_customer_username);

            //    //string customer_order_id = rdr.GetInt32(rdr.GetOrdinal("customer_order_id")) + "";
            //    //Label lbl_customer_order_id = new Label();
            //    //lbl_rate.Text = "customer_order_id " + customer_order_id + "|";
            //    //form1.Controls.Add(lbl_customer_order_id);

            //    Label br = new Label();
            //    br.Text = "  <br /> <br />";
            //    form1.Controls.Add(br);

            //    //Create a new label and add it to the HTML form

            //}

            //string field1 = (string)(Session["field1"]);
            //Response.Write(field1);
            
            try
            {
                conn.Open();
                cmd.ExecuteNonQuery();
                conn.Close();
                Response.Write("order status was updated correctly !");
                GridView1.DataBind();
            }
            catch (SqlException)
            {
                Response.Redirect("Login.aspx", true);
            }

        }
        protected void VendorMain(object sender, EventArgs e)
        {
            Response.Redirect("VendorMain.aspx", true);
        }
    }
}